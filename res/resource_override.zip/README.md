# Resource Override

An extension to help you gain full control of any website by redirecting traffic, replacing, editing, or inserting new content.

[Get the extension here](https://chrome.google.com/webstore/detail/resource-override/pkoacgokdfckfpndoffpifphamojphii).
